// src/app/layout.tsx
import '@/app/globals.css'
import { AuthProvider } from '@/components/providers/AuthProvider'
import { BottomNav } from '@/components/layout/BottomNav'
import { Toaster } from 'sonner'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body>
        <AuthProvider>
          <main className="min-h-screen bg-gradient-to-br from-violet-950 to-black pb-24">
            {children}
          </main>
          <BottomNav />
          <Toaster 
            theme="dark"
            position="top-center"
            richColors
            toastOptions={{
              style: {
                background: 'rgba(109, 40, 217, 0.2)',
                border: '1px solid rgba(124, 58, 237, 0.2)',
                backdropFilter: 'blur(8px)',
                color: 'white',
              }
            }}
          />
        </AuthProvider>
      </body>
    </html>
  )
}